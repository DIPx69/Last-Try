#include "config.h"
int dailycoin = 1000;
int dailycooldown = 30;
int silverlvl = 5;
int crimlvl = 10;
int goldlvl = 20;
int mythanlvl = 35;
int magiclvl = 50;
int minexcool = 600; // Second 
int xpboostcool = 1200; // Second 
int xpboostalert = 30; // Second
