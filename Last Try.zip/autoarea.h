void autoironarea();
void autocoalarea();
void autosilverarea();
void autocrimsteelarea();
void autogoldarea();
void automythanarea();
void automagicarea();
