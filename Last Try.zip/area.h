void ironarea();
void coalarea();
void silverarea();
void crimsteelarea();
void goldarea();
void mythanarea();
void magicarea();